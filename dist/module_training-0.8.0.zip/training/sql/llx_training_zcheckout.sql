-- Native Dolibarr checkout correlation schema.
-- Payment authority is llx_facture/llx_paiement. No TMS payment ledger or Stripe webhook tables are created.

-- Checkout session: represents a checkout process for a training session
CREATE TABLE IF NOT EXISTS llx_training_checkout_session (
    rowid integer NOT NULL AUTO_INCREMENT,
    entity integer NOT NULL,
    fk_session integer NOT NULL,
    session_ref varchar(64) NOT NULL,
    status varchar(32) NOT NULL DEFAULT 'draft',
    currency varchar(3) NOT NULL DEFAULT 'DKK',
    total_amount_ht decimal(24,8) NOT NULL DEFAULT 0,
    total_amount_ttc decimal(24,8) NOT NULL DEFAULT 0,
    tva_tx decimal(24,8) NOT NULL DEFAULT 0,
    seat_hold_id integer DEFAULT NULL,
    native_commercial_object_type varchar(32) DEFAULT NULL,
    native_commercial_object_id integer DEFAULT NULL,
    native_commercial_object_ref varchar(64) DEFAULT NULL,
    native_payment_id integer DEFAULT NULL,
    native_payment_ref varchar(64) DEFAULT NULL,
    native_payment_amount decimal(24,8) DEFAULT NULL,
    metadata_json mediumtext DEFAULT NULL,
    datec datetime NOT NULL,
    fk_user_author integer NOT NULL,
    changed_at datetime NOT NULL,
    fk_user_modifier integer NOT NULL,
    PRIMARY KEY (rowid),
    UNIQUE KEY uk_training_checkout_session_entity_id (entity, rowid),
    KEY idx_training_checkout_session (entity, fk_session),
    KEY idx_training_checkout_status (entity, status),
    KEY idx_training_checkout_seat_hold (entity, seat_hold_id),
    KEY idx_training_checkout_datec (entity, datec),
    CONSTRAINT fk_llx_training_checkout_session FOREIGN KEY (entity, fk_session) REFERENCES llx_training_session(entity, rowid) ON DELETE CASCADE,
    CONSTRAINT fk_llx_training_checkout_seat_hold FOREIGN KEY (seat_hold_id) REFERENCES llx_training_seat_hold(rowid) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Checkout participant: individual participants in a checkout session
CREATE TABLE IF NOT EXISTS llx_training_checkout_participant (
    rowid integer NOT NULL AUTO_INCREMENT,
    entity integer NOT NULL,
    fk_checkout_session integer NOT NULL,
    fk_enrollment integer DEFAULT NULL,
    fk_contact integer NOT NULL,
    fk_learner integer DEFAULT NULL,
    first_name varchar(128) NOT NULL,
    last_name varchar(128) NOT NULL,
    email varchar(255) DEFAULT NULL,
    phone varchar(64) DEFAULT NULL,
    status varchar(32) NOT NULL DEFAULT 'pending',
    datec datetime NOT NULL,
    fk_user_author integer NOT NULL,
    changed_at datetime NOT NULL,
    fk_user_modifier integer NOT NULL,
    PRIMARY KEY (rowid),
    UNIQUE KEY uk_training_checkout_participant_entity_id (entity, rowid),
    KEY idx_training_checkout_participant_session (entity, fk_checkout_session),
    KEY idx_training_checkout_participant_enrollment (entity, fk_enrollment),
    KEY idx_training_checkout_participant_contact (entity, fk_contact),
    KEY idx_training_checkout_participant_learner (entity, fk_learner),
    CONSTRAINT fk_llx_training_checkout_participant_session FOREIGN KEY (entity, fk_checkout_session) REFERENCES llx_training_checkout_session(entity, rowid) ON DELETE CASCADE,
    CONSTRAINT fk_llx_training_checkout_participant_enrollment FOREIGN KEY (entity, fk_enrollment) REFERENCES llx_training_enrollment(entity, rowid),
    -- Dolibarr llx_socpeople guarantees rowid as its key, but not a composite (entity, rowid) index.
    -- Contact entity access is checked by TrainingAccess before participant persistence.
    CONSTRAINT fk_llx_training_checkout_participant_contact FOREIGN KEY (fk_contact) REFERENCES llx_socpeople(rowid),
    CONSTRAINT fk_llx_training_checkout_participant_learner FOREIGN KEY (entity, fk_learner) REFERENCES llx_training_learner(entity, rowid)
) ENGINE=InnoDB;

-- Outbox: async processing queue for emails and other notifications
CREATE TABLE IF NOT EXISTS llx_training_outbox (
    rowid integer NOT NULL AUTO_INCREMENT,
    entity integer NOT NULL,
    object_type varchar(64) NOT NULL,
    fk_object integer NOT NULL,
    action varchar(64) NOT NULL,
    recipient_type varchar(32) NOT NULL,
    recipient_id integer NOT NULL,
    recipient_email varchar(255) DEFAULT NULL,
    subject varchar(255) NOT NULL,
    body_text mediumtext NOT NULL,
    body_html mediumtext DEFAULT NULL,
    metadata_json mediumtext DEFAULT NULL,
    status varchar(32) NOT NULL DEFAULT 'pending',
    attempts integer NOT NULL DEFAULT 0,
    last_attempt datetime DEFAULT NULL,
    last_error varchar(255) DEFAULT NULL,
    scheduled_at datetime DEFAULT NULL,
    datec datetime NOT NULL,
    fk_user_author integer NOT NULL,
    changed_at datetime NOT NULL,
    fk_user_modifier integer NOT NULL,
    PRIMARY KEY (rowid),
    UNIQUE KEY uk_training_outbox_entity_id (entity, rowid),
    KEY idx_training_outbox_status (entity, status),
    KEY idx_training_outbox_object (entity, object_type, fk_object),
    KEY idx_training_outbox_scheduled (entity, status, scheduled_at),
    KEY idx_training_outbox_recipient (entity, recipient_type, recipient_id),
    KEY idx_training_outbox_datec (entity, datec)
) ENGINE=InnoDB;
